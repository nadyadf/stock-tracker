import '../styles/css/main.css';
import '../styles/css/variables.css';
import '../scripts/views/main';
